# NexusHub

**A product catalog and inventory management platform for independent sellers.**

NexusHub gives small business owners and independent sellers a single place to manage their product listings — track inventory levels, control visibility, and expose their catalog through a clean REST API consumed by a native Android app.

[![Spring Boot](https://img.shields.io/badge/Spring%20Boot-3.2.4-6DB33F?logo=springboot&logoColor=white)](https://spring.io/projects/spring-boot)
[![Kotlin](https://img.shields.io/badge/Kotlin-2.1.0-7F52FF?logo=kotlin&logoColor=white)](https://kotlinlang.org)
[![Jetpack Compose](https://img.shields.io/badge/Jetpack%20Compose-BOM%202024.12-4285F4?logo=jetpackcompose&logoColor=white)](https://developer.android.com/compose)
[![Java](https://img.shields.io/badge/Java-17-ED8B00?logo=openjdk&logoColor=white)](https://openjdk.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## The Problem It Solves

Small sellers typically manage their product catalog across spreadsheets, notes apps, or social media DMs. NexusHub centralizes that workflow:

- A seller registers and publishes listings with price and stock information
- The system automatically tracks when products run out of stock
- Buyers browse an up-to-date catalog filtered by status and category
- Sellers control product visibility without deleting historical data

---

## Features

### Catalog Management
- Create, update, and soft-delete product listings
- Automatic status transitions: `ACTIVE → OUT_OF_STOCK` when stock hits 0
- Manual visibility control via `ACTIVE / INACTIVE` status
- Low-stock warnings when inventory drops below 5 units
- Duplicate listing prevention per seller (case-insensitive name check)

### Search & Discovery
- Full-text search across product names and descriptions
- Filter by category
- Paginated listing with infinite scroll on Android

### Catalog Statistics
- Aggregated counts by status (active, out-of-stock, inactive)
- Price range (average, highest, lowest) across active products
- Product distribution by category

### Mobile App (Android)
- Login and registration with persistent session
- Product grid with status badges (low-stock, out-of-stock)
- Product detail view with full information
- Create product form with client-side validation

---

## Tech Stack

### Backend
| Component | Technology |
|-----------|-----------|
| Language | Java 17 |
| Framework | Spring Boot 3.2 |
| ORM | Spring Data JPA + Hibernate |
| Database (dev) | H2 in-memory |
| Database (prod) | MySQL 8 |
| Build | Maven |
| API Docs | springdoc-openapi (Swagger UI) |
| Validation | Jakarta Bean Validation (JSR-380) |
| Boilerplate | Lombok |

### Android
| Component | Technology |
|-----------|-----------|
| Language | Kotlin 2.1 |
| UI | Jetpack Compose + Material3 |
| Architecture | MVVM + StateFlow |
| HTTP Client | Retrofit 2 + OkHttp |
| Image Loading | Coil |
| Session | DataStore Preferences |
| Navigation | Navigation Compose |

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                   Android Client                     │
│  UI (Compose) → ViewModel → Repository → Retrofit   │
└────────────────────────┬────────────────────────────┘
                         │ HTTP / JSON
┌────────────────────────▼────────────────────────────┐
│                  Spring Boot API                     │
│  Controller → Service → Repository → JPA → Database │
└─────────────────────────────────────────────────────┘
```

### Backend layers

```
com.nexushub/
├── controller/     REST endpoints — input validation, HTTP status codes
├── service/        Business logic — rules, transitions, ownership checks
├── repository/     JPA interfaces — queries, aggregations
├── entity/         JPA entities — Product, User, ProductStatus
├── dto/            Java Records — request/response contracts
├── exception/      GlobalExceptionHandler, typed exceptions
└── config/         CORS, OpenAPI, DataSeeder
```

### Android layers

```
com.nexushub.android/
├── data/
│   ├── api/        Retrofit interface + OkHttp client
│   ├── model/      Data classes (request / response)
│   └── repository/ Data layer — wraps API calls in NetworkResult<T>
├── ui/
│   ├── auth/       LoginScreen, RegisterScreen, AuthViewModel
│   ├── product/    ProductListScreen, ProductDetailScreen,
│   │               CreateProductScreen, ProductViewModel
│   ├── components/ Reusable Composables (ProductCard, states)
│   ├── navigation/ NavGraph + Routes
│   └── theme/      Material3 color scheme, typography
└── util/
    ├── NetworkResult.kt   Sealed class — Success / Error / Loading
    └── SessionManager.kt  DataStore-backed token persistence
```

---

## Product Status Model

```
                  ┌─────────────────┐
     create (stock > 0) ──►  ACTIVE  ◄── seller re-activates
                  └────────┬────────┘
                           │
              stock reaches 0 (auto)     seller hides listing
                           │                    │
                  ┌────────▼────────┐   ┌───────▼────────┐
                  │  OUT_OF_STOCK   │   │    INACTIVE     │
                  └────────┬────────┘   └────────────────-┘
                           │
              add stock via PUT /products/{id}
                           │
                  ┌────────▼────────┐
                  │     ACTIVE      │
                  └─────────────────┘
```

---

## API Endpoints

Base URL: `http://localhost:8080`  
Auth header: `X-Auth-Token: <token>` (returned on login/register)

### Authentication

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/auth/register` | ❌ | Create account |
| POST | `/auth/login` | ❌ | Login, returns token |

### Products

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/products` | ❌ | Paginated active listings |
| GET | `/products/{id}` | ❌ | Product detail |
| GET | `/products/search?query=` | ❌ | Full-text search |
| GET | `/products/category/{cat}` | ❌ | Filter by category |
| GET | `/products/stats` | ❌ | Catalog statistics |
| GET | `/products/my` | ✅ | Seller's own products |
| POST | `/products` | ✅ | Create listing |
| PUT | `/products/{id}` | ✅ | Full update |
| PATCH | `/products/{id}/status` | ✅ | Change status |
| DELETE | `/products/{id}` | ✅ | Soft-delete (sets INACTIVE) |

### Example requests

**Register**
```bash
curl -X POST http://localhost:8080/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name": "Jane Doe", "email": "jane@example.com", "password": "secret123"}'
```

**Login**
```bash
curl -X POST http://localhost:8080/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "alice@nexushub.dev", "password": "password123"}'
```

**Create product**
```bash
curl -X POST http://localhost:8080/products \
  -H "Content-Type: application/json" \
  -H "X-Auth-Token: demo-token-alice-001" \
  -d '{
    "name": "USB-C Hub 7-in-1",
    "description": "Aluminum hub with 4K HDMI, 3x USB-A, SD card reader.",
    "price": 49.99,
    "stock": 25,
    "category": "Electronics"
  }'
```

**Catalog stats**
```bash
curl http://localhost:8080/products/stats
```

**Toggle visibility**
```bash
curl -X PATCH http://localhost:8080/products/1/status \
  -H "Content-Type: application/json" \
  -H "X-Auth-Token: demo-token-alice-001" \
  -d '{"status": "INACTIVE"}'
```

---

## Running the Project

### Prerequisites
- Java 17+
- Maven 3.8+
- Android Studio Hedgehog (2023.1.1) or later
- Android emulator or physical device (API 26+)

---

### Backend

```bash
cd nexushub-backend
./mvnw spring-boot:run
```

The server starts on `http://localhost:8080`.

| URL | Description |
|-----|-------------|
| http://localhost:8080/swagger-ui.html | Interactive API docs |
| http://localhost:8080/h2-console | Database console (JDBC URL: `jdbc:h2:mem:nexushubdb`) |
| http://localhost:8080/api-docs | OpenAPI JSON spec |

**Demo accounts (seeded automatically)**

| Email | Password | Token |
|-------|----------|-------|
| alice@nexushub.dev | password123 | `demo-token-alice-001` |
| bob@nexushub.dev | password123 | `demo-token-bob-002` |

**Switch to MySQL**

In `application.properties`, comment out the H2 block and uncomment the MySQL block:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/nexushubdb?useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=yourpassword
spring.jpa.database-platform=org.hibernate.dialect.MySQLDialect
spring.jpa.hibernate.ddl-auto=update
```
Then create the schema: `CREATE DATABASE nexushubdb CHARACTER SET utf8mb4;`

---

### Android App

1. Open `nexushub-android/` in Android Studio
2. Wait for Gradle sync to complete
3. Run on emulator or device

The app is pre-configured to point to `http://10.0.2.2:8080` (Android emulator's alias for localhost).

**Physical device:** Update `BASE_URL` in `app/build.gradle.kts`:
```kotlin
buildConfigField("String", "BASE_URL", "\"http://192.168.x.x:8080/\"")
```
Replace `192.168.x.x` with your machine's local IP address.

---

## Business Rules Reference

| Rule | Where enforced |
|------|---------------|
| Duplicate product names per seller are rejected | `ProductService.assertNoDuplicateName()` |
| Price must be between $0.01 and $99,999.99 | `ProductRequest` DTO validation |
| Stock 0 on create → status is `OUT_OF_STOCK` | `ProductService.resolveStatus()` |
| Stock drops to 0 on update → auto `OUT_OF_STOCK` | `ProductService.updateProduct()` |
| Cannot activate a product with 0 stock | `ProductService.updateStatus()` |
| `OUT_OF_STOCK` cannot be set manually | `ProductService.updateStatus()` |
| Only the owner can update or delete a product | `ProductService.assertOwnership()` |
| Deleted products are soft-deleted (INACTIVE) | `ProductService.deleteProduct()` |

---

## Possible Extensions

- [ ] JWT-based authentication with refresh tokens  
- [ ] Order and cart management  
- [ ] Image upload via cloud storage (S3 / Cloudinary)  
- [ ] Seller analytics dashboard  
- [ ] Push notifications for low-stock alerts  
- [ ] Docker Compose setup for backend + MySQL  
- [ ] Unit tests with JUnit 5 + Mockito  

---

## License

Distributed under the MIT License. See [LICENSE](LICENSE) for details.
